"""
Credit Risk Assessment Web App
===============================

A beginner-friendly Streamlit app for predicting credit risk.
Simply input loan details and get instant predictions with explanations.
"""

import streamlit as st
import pandas as pd
import numpy as np
import pickle

# Page configuration
st.set_page_config(page_title="Credit Risk Assessment", layout="centered")

# Add some CSS for better appearance
st.markdown("""
<style>
    .main {
        padding: 2rem 1rem;
    }
    .stButton>button {
        width: 100%;
        background-color: #FF4B4B;
        color: white;
        font-weight: bold;
    }
    .prediction-box {
        padding: 20px;
        border-radius: 10px;
        margin: 20px 0;
    }
    .good-loan {
        background-color: #d4edda;
        border: 2px solid #28a745;
    }
    .bad-loan {
        background-color: #f8d7da;
        border: 2px solid #dc3545;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def load_model():
    """Load the trained model and explainer"""
    try:
        with open('best_model.pkl', 'rb') as f:
            model = pickle.load(f)
        with open('feature_names.pkl', 'rb') as f:
            feature_names = pickle.load(f)
        with open('best_threshold.pkl', 'rb') as f:
            best_threshold = float(pickle.load(f))
        
        return model, feature_names, best_threshold
    except FileNotFoundError as e:
        st.error(f"Model files not found. Please run 'train_model.py' first.")
        st.stop()
        return None, None, None

# Load model
model, feature_names, best_threshold = load_model()

# Title
st.title("🏦 Credit Risk Assessment Tool")
st.markdown("Predict whether a loan is likely to be paid back or charged off")

# Input form
st.header("📝 Loan Information")

# Basic information
col1, col2 = st.columns(2)

with col1:
    loan_amnt = st.number_input(
        "Loan Amount ($)", 
        min_value=500, 
        max_value=200000, 
        value=10000, 
        step=500,
        help="The amount the borrower wants to borrow"
    )
    
    int_rate = st.number_input(
        "Interest Rate (%)", 
        min_value=0.0, 
        max_value=50.0, 
        value=10.5, 
        step=0.1,
        help="The annual interest rate charged"
    )
    
    term_months = st.selectbox(
        "Loan Term (months)",
        options=[36, 60],
        help="Number of months to pay back the loan"
    )

with col2:
    annual_inc = st.number_input(
        "Annual Income ($)", 
        min_value=0, 
        max_value=1000000, 
        value=60000, 
        step=1000,
        help="The borrower's annual income"
    )
    
    installment = st.number_input(
        "Monthly Payment ($)",
        min_value=0,
        max_value=10000,
        value=300,
        step=50,
        help="The monthly payment amount"
    )
    
    home_ownership = st.selectbox(
        "Home Ownership",
        options=["OWN", "MORTGAGE", "RENT"],
        help="Borrower's home ownership status"
    )

# Advanced settings
with st.expander("⚙️ Advanced Settings"):
    threshold = st.slider(
        "Decision Threshold", 
        0.05, 
        0.95, 
        float(best_threshold), 
        0.01,
        help="Higher values = stricter (fewer loans approved)"
    )
    
    st.caption(f"Optimal threshold: {best_threshold:.2f}")

# Prediction button
if st.button("🔮 Predict Credit Risk", type="primary"):
    # Calculate derived features
    loan_to_income = loan_amnt / max(annual_inc, 1)
    log_annual_inc = np.log1p(max(annual_inc, 0))
    installment_to_income = installment / max(annual_inc / 12, 1)  # Monthly installment vs monthly income
    
    # Map home ownership to numeric
    home_ownership_map = {"OWN": 3, "MORTGAGE": 2, "RENT": 1, "OTHER": 0}
    home_ownership_numeric = home_ownership_map.get(home_ownership, 1)
    
    # Create feature vector
    features_dict = {
        'loan_amnt': loan_amnt,
        'int_rate': int_rate,
        'annual_inc': annual_inc,
        'installment': installment,
        'loan_to_income': loan_to_income,
        'log_annual_inc': log_annual_inc,
        'installment_to_income': installment_to_income,
        'term_numeric': term_months,
        'home_ownership_numeric': home_ownership_numeric
    }
    
    X = pd.DataFrame([features_dict])
    
    # Ensure all features are present
    for feat in feature_names:
        if feat not in X.columns:
            X[feat] = 0.0
    
    # Reorder features to match training
    X = X[feature_names]
    
    # Get prediction probability
    proba = float(model.predict_proba(X)[0][1])
    
    # Make prediction based on threshold
    pred = int(proba >= threshold)
    
    # Display result
    st.header("📊 Prediction Result")
    
    # Result box with color coding
    result_class = "bad-loan" if pred == 1 else "good-loan"
    emoji = "❌" if pred == 1 else "✅"
    result_text = "HIGH RISK - Likely to Default" if pred == 1 else "LOW RISK - Likely to Repay"
    
    st.markdown(f"""
    <div class="prediction-box {result_class}">
        <h2>{emoji} {result_text}</h2>
        <p><b>Default Probability: {proba:.1%}</b></p>
    </div>
    """, unsafe_allow_html=True)
    
    # Detailed metrics
    st.subheader("📈 Risk Analysis")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(
            "Loan-to-Income", 
            f"{loan_to_income:.2f}",
            help="Lower is better. Shows borrowing ratio."
        )
    
    with col2:
        risk_level = "High" if proba > 0.5 else "Low" if proba < 0.3 else "Medium"
        st.metric("Risk Level", risk_level)
    
    with col3:
        st.metric("Threshold Used", f"{threshold:.2f}")
    
    # Feature importance (SHAP values)
    st.subheader("🔍 Why This Prediction?")
    
    try:
        import shap
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X)
        
        if isinstance(shap_values, list):
            shap_values = shap_values[1]  # Get values for bad loan class
        
        # Create feature contributions
        contributions = {}
        for i, feat in enumerate(feature_names):
            contributions[feat] = float(shap_values[0][i])
        
        # Convert to dataframe and sort
        df_contrib = pd.DataFrame.from_dict(
            contributions, 
            orient='index', 
            columns=['Contribution']
        ).sort_values('Contribution', ascending=False)
        
        # Display as bar chart
        st.bar_chart(df_contrib, height=300)
        
        # Show contribution table
        st.write("**Feature Contributions:**")
        st.caption("Positive values push toward BAD loan, negative toward GOOD loan")
        
        # Format the table nicely
        df_display = df_contrib.copy()
        df_display['Impact'] = df_display['Contribution'].apply(
            lambda x: "🔴 Risk Increasing" if x > 0.1 
            else "🟢 Risk Decreasing" if x < -0.1 
            else "⚪ Neutral"
        )
        
        st.dataframe(df_display, use_container_width=True)
        
    except Exception as e:
        st.info("SHAP explanations are not available. Please ensure the model was trained with SHAP.")
        st.caption(f"Error: {str(e)}")

# Footer
st.markdown("---")
st.caption("💡 Tip: Lower interest rates, higher income, and lower loan-to-income ratios generally mean lower risk")
